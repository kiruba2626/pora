package com.example.pora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
